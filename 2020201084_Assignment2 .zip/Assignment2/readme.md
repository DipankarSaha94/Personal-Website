# Assignemnt 2



## Page1

### CSS

* I have used CSS to design the page and make page compatible with the window size.



### JS

* I have used JS to welcome the user and geet the user based on the current time.



## Page2

### HTML

* Contains my personal details about education and experience.



### CSS

* I have used CSS to design the page and make page compatible with the window size.



## Page3
### HTML

* Contains the details and image of the persons who are my idols.



### CSS

* I have used CSS to design the page and make page compatible with the window size.
